/*!
 * 
 * RAF Ventures Online Mall app
 * 
 * Author: @dhaveed
 * Website: http://syndic8tech.tk
 * 
 */

if (typeof $ === 'undefined') { throw new Error('This application\'s JavaScript requires jQuery'); }
var app = angular.module('rafApp');
	app.controller('orderCtrl', ['$scope', function($scope){
		$scope.pickedProducts = 
		[
			{id: 1, name: "Milk Powder", size: "Medium", brand: "Peak", quantity: "2", unit: "24", total: 48},
			{id: 2, name: "Air Conditioner", size: "Small", brand: "Haier Thermocool", quantity: "3", unit: "500", total: 1500},
			{id: 3, name: "Refined Sugar", size: "Medium", brand: "Dangote", quantity: "20", unit: "600", total: 12000},
			{id: 4, name: "Cement", size: "Big", brand: "Elephant", quantity: "60", unit: "5", total: 300},
		];

		$scope.id = function(){
			return $scope.pickedProducts.length + 1;
		}

		$scope.pick = function(){
			$scope.pickedProducts.push({id: $scope.id(), name: $scope.name,size: $scope.size,brand: $scope.brand,quantity: $scope.quantity,unit: 600,total: 12000});
			 $scope.name = "";
			 $scope.size = "";
			 $scope.brand = "";
			 $scope.quantity = "";
		};
	}]);



/*=========================================================
 * Module: products controller
 * Functions :
 * Provides functions for product fetching and display.
 * also controls adding of items to cart
 * by @dhaveed_adegoke ;-)
 =========================================================*/


	app.controller('productsCtrl', function($rootScope,$scope,$http){
		$scope.test = "testing scopes";
		$scope.productList = {};

		//reading the products array from the json
		 $http.get('data/products.json').then(function(response){

		 	//storing the array from the json in the variable productList
				return	$scope.productList = response.data;
				});
	});
