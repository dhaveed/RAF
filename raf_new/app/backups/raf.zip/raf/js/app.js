/*!
 * 
 * RAF Ventures Online Mall app
 * 
 * Author: @dhaveed
 * Website: http://syndic8tech.tk
 * 
 */

if (typeof $ === 'undefined') {
 throw new Error('This application\'s JavaScript requires jQuery'); 
}

var app = angular.module('rafApp', ['ui.router',]);



app.config(['$urlRouterProvider', '$stateProvider', function($urlRouterProvider, $stateProvider) {
	$urlRouterProvider.otherwise('/');

	$stateProvider.state('dashboard', {
		url: '/',
		templateUrl: 'templates/dashTest.html'
	})
	.state('products', {
		url: '/products',
		templateUrl: 'templates/products.html'
	})
	.state('booking', {
		url: '/booking',
		templateUrl: 'templates/booking.html'
	})
	.state('book', {
		url: '/book',
		templateUrl: 'templates/book.html'
	})
	.state('settings', {
		url: '/settings',
		templateUrl: 'templates/settings.html'
	})
	.state('help', {
		url: '/help',
		templateUrl: 'templates/help.html'
	})
}]);

/*Scope Globals
		$rootScope.app =
			{
				name: "RAF Ventures",
				author: "Revolve T3chnologies, MosTech, immTech",
				description: "Online Mall App",
				year: ((new Date()).getFullYear()),
				owner: "RAF Ventures"
			};
		$rootScope.testUser = {
			name: 'Adegoke David',
			accountType: 'Admin',
			picture: 'plugins/plugins/images/users/varun.jpg'
		};*/